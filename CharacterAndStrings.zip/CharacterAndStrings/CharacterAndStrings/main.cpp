//
//  main.cpp
//  CharacterAndStrings
//
//  Created by Janera Dobson on 4/16/21.
//

#include <iostream>

void f() {
char buf[12];
std::cout<<"\n Enter A String: ";
std::cin >> buf;
std::cout<<"\n You Entered: ";
std::cout<<buf;
std::cout << std::endl;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    f();
    return 0;
}
