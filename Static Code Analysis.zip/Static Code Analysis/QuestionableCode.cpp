// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>

// TODO: You are going to compare the warnings & errors between Visual Studio and CppCheck.
//  Make sure you are using CppCheck 2.1 or greater
//
//  1. Create a Visual Studio Console project with this file as the only file
//  2. Compile it and check the warning and errors
//  3. Create a CppCheck project to analyze a Visual Studio project with this file.
//  4. In CppCheck Edit / Preferences / General Tab: Set Display error id in column "Id", Enable inline suppressions, and Check for inconclusive errors also
//  5. In CppCheck View, Select Check All to ensure all types of checks are enabled
//  6. In CppCheck Analyze, set the C++ Standard to C++17, and Enforce C++
//  7. Make sure to run the analysis
//  8. Save the results to a file (XML format)
//  9. Take a screen shot of the Visual Studio Error list (all errors, warnings, and messages)
//  10. Identify all messages from CppCheck NOT identified in Visual Studio.
//      For each message not in both:
//        Identify the risk as: RISK or NOT RISK
//        Identify which system (Visual Studio or CppCheck) found the issue
//        Provide a couple of sentences describing the issue found

class C
{
    std::set<int> typedefs;
    bool is_type(int type) const
    {
        if (typedefs.find(type) != typedefs.end())
            return is_type(type); // BUG: endless recursion
        return false;
    }
};

class A
{
    int x;
    A(const A& other) {} //RISK FOUND ON CPPCHECK. Member variable 'A::x' is not initialized in the constructor.
};

class MySpecialType
{
public:
    int MyVal = 1;

    void DontThrow() noexcept
    {
        throw "Ha! I threw anyway!"; //RISK FOUND ON CPPCHECK.Exception thrown in function declared not to throw exceptions.
    }
};

void foo(int** a)
{
    int b = 1;
    *a = &b; //RISK FOUND ON CPPCHECK
    /* Dangerous assignment - the function parameter is assigned the address of a local auto-variable. Local auto-variables
     are reserved from the stack which is freed when the function ends. So the pointer to a local variable is invalid after the function ends.
     */
}

void work_with_arrays(int count)
{
    int buf[10]; //RISK FOUND ON CPPCHECK. Either the condition 'count==1000' is redundant or the array 'buf[10]' is accessed at index 1000, which is out of bounds.
 /*The scope of the variable 'buf' can be reduced. Warning: Be careful when fixing this message,
    especially when there are inner loops. Here is an example where cppcheck will write that the scope for 'i'
    can be reduced:\012void f(int x)\012{\012    int i = 0;\012    if (x) {\012
    it's safe to move 'int i = 0;' here\012        for (int n = 0; n < 10; ++n) {\012
    it is possible but not safe to move 'int i = 0;' here\012            do_something(&i);\012        }
    \012    }\012}\012When you see this message it is always safe to reduce the variable scope 1 level.
  */

    if (count == 1000) //RISK FOUND ON CPPCHECK. Assuming that condition 'count==1000' is not redundant
        buf[count] = 0; // <- ERROR //RISK FOUND ON CPPCHECK. Array index out of bounds. Variable 'buf' is assigned a value that is never used.
    
}

void do_something_useless()
{
    int sum = 0;
    for (auto i = 0; i < 1000; ++i)
    {
        sum += i;
    }

    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);
    std::vector<int>::iterator iter;
    for (iter = items.begin(); iter != items.end(); ++iter) {//RISK FOUND ON CPPCHECK
        /* The iterator 'iter' is invalid after the element it pointed to has been erased. Dereferencing or comparing it with another iterator is invalid operation. Id: eraseDereference.
         */
        if (*iter == 2) {
            items.erase(iter); //RISK FOUND ON CPPCHCK. Id: eraseDereference.
        }
    }
}

int a;
bool my_function()
{
    a = 1 + 2;
    return a;
}

struct Token
{
    Token* next() { return nullptr; }
};

int foo(Token* tok)
{
    while (tok);
    tok = tok->next(); //RISK FOUND CPPCHECK. Assignment of function parameter has no effect outside the function. Did you forget dereferencing it?
    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 }; //RISK FOUND ON CPPCHECK. Variable 'counts' is assigned a value that is never used.
    int x = 0; //RISK FOUND ON CPPCHECK. Variable 'x' is assigned a value that is never used.
    int y = 0; //RISK FOUND ON CPPCHECK. Variable 'y' is assigned a value that is never used.
    int z = 0; 

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    //do_something_useless();

    work_with_arrays(10);

    assert(z = 2); //RISK FOUND ON CPPCHECK. Variable 'z' is modified insert assert statement.
    /*Assert statements are removed from release builds so
    the code insideassert statement is not executed. If the code is needed also in release builds, this is a bug.
     */
    assert(my_function() == 3); //RISK FOUND ON VSCODE & CPPCHECK. Comparison of a boolean expression with an integer other than 0 or 1.
    /*Non-pure function: 'my_function' is called inside assert statement. Assert statements are removed from release builds
     so the code inside assert statement is not executed. If the code is needed also in release builds, this is a bug.
     */

    try
    {
        int x = 5;
        int y = 5;
        int z = 5;
        std::cout << "x + y + z = " << (x + y + z) << std::endl;
    }
    catch (...)
    {

    }

    int* c;
    foo(&c);

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
